 <?php if(!empty($_SESSION['user_id'])) {
      $user_id = $_SESSION['user_id'];
     }
 ?>      

    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <a class="navbar-brand" href="index.php" style="width: 200px">
            <img src="images/pixie.png" alt="" />
          <!--   <span>
             
            </span> -->
          </a>

          <div class="navbar-collapse" id="">
            <div class="container">
              <div class=" mr-auto flex-column flex-lg-row align-items-center">
                <ul class="navbar-nav justify-content-between ">
                  <div class="d-none d-lg-flex">
                    <li class="nav-item">
                      <a class="nav-link" href="fruit.html">
                        </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" href="service.html">
                      
                      </a>
                    </li>
                  </div>
                  <div class=" d-none d-lg-flex">
                    <li class="nav-item">

                       <?php if(empty($_SESSION['user_id'])): ?>
                           
                            <div  style="color:white!important; cursor: pointer;" data-toggle="modal" data-target="#modal_log_reg">
                            <b style="color:white!important">  Login / Register </b>
                            </div>

                      <?php else: ?>

                        
                            <b style="color:white!important; "> 

                              <?php 
                               $qryCountCart = mysqli_query($db, "SELECT DISTINCT order_id FROM cart WHERE user_id = '$user_id' ");

                             
                                $num_rows = mysqli_num_rows($qryCountCart);
                               
                               ?>
                               <a href="cart.php"><img src="images/shopping-cart.png" style="width: 28px; "> <sup id="cart_product_number" style="color:black;margin-right: 8px;"><?php echo $num_rows; ?></sup></a>
                              <?php echo "Hi, " . $_SESSION['fname']; ?> |
                               <a style="color:white; cursor: pointer;" href="logic/logout.php">Logout</a>

                            </b>
                        

                     <?php endif; ?>

                    </li>
                    <!-- <form class="form-inline my-2 ml-5 mb-3 mb-lg-0">
                      <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit"></button>
                    </form> -->
                  </div>
                </ul>
              </div>
            </div>

            <div class="custom_menu-btn">
              <button onclick="openNav()"></button>
            </div>
            <div id="myNav" class="overlay">
              <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
              <div class="overlay-content">
                <a href="index.php">HOME</a>
                
                <?php
                if(empty($_SESSION['user_id'])) {
                    echo ' <a onclick="closeNav()" href="" data-toggle="modal"  data-target="#modal_log_reg" >LOGIN/REGISTER</a>';
                  }    
                ?>   

                 <a href="users.php">USERS</a>

                <a href="product.php">PRODUCTS</a>

                 <a href="setting.php">SETTING</a>

                  <a href="cart.php">MY CART</a>

                  <a href="orders.php">MY ORDERS</a>

                  


                 <a href="logic/logout.php">LOGOUT</a>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>


     <?php       if(!empty($_SESSION['alert'])) 
                                {
                                echo $_SESSION['alert'];
                                unset($_SESSION['alert']);
                                }
                            ?>
    <!-- end header section -->